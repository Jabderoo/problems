bot = {'name': '', 'pos_x': 0, 'pos_y': 0, 'face': 'n', 'history': []}


def get_bot_name():
        bot['name'] = input("What do you want to name your robot? ")
        print(f"{bot['name']}: Hello kiddo!")


def handle_command_input():

        on = True
        while on:
            command = input(f"{bot['name']}: What must I do next? ")
            com_split = command.split()
            com = com_split[0].lower()

            if com == 'off':
                print(f"{bot['name']}: Shutting down..")
                break

            elif com == 'help' and len(com_split) == 1:
                help_command()

            elif com == 'forward' and len(com_split) == 2 or com == 'back' and len(com_split) == 2:
                bot['history'].append(command)
                movement(com_split)

            elif com == 'left' and len(com_split) == 1 or com == 'right' \
                and len(com_split) == 1:
                bot['history'].append(command)
                change_face(command)

            elif com == 'sprint' and len(com_split) == 2:
                bot['history'].append(command)
                run_sprint(com_split)

            elif com == 'replay' and len(com_split) == 1:
                do_replay(com_split)

            elif com == 'replay' and com_split[1].isdigit() == True and len(com_split) == 2:
                do_replay_range(com_split)
            
            elif com == 'replay' and com_split[1].isdigit() == True and com_split[2].lower() == 'silent' and len(com_split) == 3:
                do_replay_range_silent(com_split)

            elif com == 'replay' and com_split[1].isdigit() == True and com_split[2].lower() == 'reversed' and len(com_split) == 3:
                do_replay_range_reversed(com_split)

            elif com == 'replay' and '-' in com_split[1] and len(com_split) == 2:
                dash_split = com_split[1].split('-')
                if dash_split[0].isdigit() == True and dash_split[1].isdigit() == True \
                    and int(dash_split[0]) > int(dash_split[1]):
                    do_replay_range_dash(com_split)
                else:
                    print(bot['name'], ": Sorry, I did not understand '", command, "'.", sep='')
                
            elif com == 'replay' and com_split[1].lower() == 'silent' and len(com_split) == 2:
                do_replay_silent(com_split)
            
            elif com == 'replay' and com_split[1].lower() == 'reversed' and len(com_split) == 2:
                do_replay_reversed(com_split)

            elif com == 'replay' and com_split[1].lower() == 'reversed' and \
                com_split[2].lower() == 'silent' and len(com_split) == 3:
                do_replay_reversed_silent(com_split)

            else:
                print(bot['name'], ": Sorry, I did not understand '", command, "'.", sep='')

def help_command():
        print(
                        """I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
FORWARD - move forward by specified number of steps, e.g. 'FORWARD 10'
BACK - move backward by specified number of steps, e.g. 'BACK 10'
RIGHT - turn right by 90 degrees
LEFT - turn left by 90 degrees
SPRINT - sprint forward according to a formula"""
                                )
        return help_command


def movement(command, sprint = False, silent = False):

        steps = int(command[1])
        com = command[0].lower()
        face = bot['face']

        if face == 'e' and com == 'forward' and bot['pos_x'] + steps <= 100  or \
        face == 'w' and com  == 'back' and bot['pos_x'] + steps <= 100:
                
            bot['pos_x'] = bot['pos_x'] + steps
            if silent == False:
                print(f" > {bot['name']} moved {com } by {steps} steps.")


        elif face == 'w' and com == 'forward' and bot['pos_x'] - steps >= -100 or \
        face == 'e' and com == 'back' and bot['pos_x'] - steps >= -100:

            bot['pos_x'] = bot['pos_x'] - steps
            if silent == False:
                print(f" > {bot['name']} moved {com} by {steps} steps.")


        elif face == 'n' and com  == 'forward' and bot['pos_y'] + steps <= 200 or \
        face == 's' and com  == 'back' and bot['pos_y'] + steps <= 200:
                
            bot['pos_y'] = bot['pos_y'] + steps
            if silent == False:
                print(f" > {bot['name']} moved {com} by {steps} steps.")

        
        elif face == 's' and com  == 'forward' and bot['pos_y'] - steps >= -200 or \
        face == 'n' and com  == 'back' and bot['pos_y'] - steps >= -200:

            bot['pos_y'] = bot['pos_y'] - steps
            
            if silent == False:
                print(f" > {bot['name']} moved {com} by {steps} steps.")

        else:
            print(f"{bot['name']}: Sorry, I cannot go outside my safe zone.")

        if sprint == False:
                if silent == False:
                    print(f" > {bot['name']} now at position ({bot['pos_x']},{bot['pos_y']}).")


def change_face(command, silent = False):
        if bot['face'] == 'e' and command == 'right' \
            or bot['face'] == 'w' and command == 'left':
                bot['face'] = 's'

        elif bot['face'] == 'w' and command == 'right' \
            or bot['face'] == 'e' and command == 'left':
                bot['face'] = 'n'

        elif bot['face'] == 'n' and command == 'right' \
            or bot['face'] == 's' and command == 'left':
                bot['face'] = 'e'

        elif bot['face'] == 's' and command == 'right' \
            or bot['face'] == 'n' and command == 'left':
                bot['face'] = 'w'
        if silent == False:
            print(f" > {bot['name']} turned {command}.")
            print(f" > {bot['name']} now at position ({bot['pos_x']},{bot['pos_y']}).")


def run_sprint(command, silent = False):
        """
        Sprints the robot, i.e. let it go forward steps + \
            (steps-1) + (steps-2) + .. + 1 number of steps, in iterations
        """
        command[0] = 'forward'
        command[1] = int(command[1])

        if int(command[1]) == 1 and silent == False:
            movement(command)
        elif int(command[1]) == 1 and silent == True:
            movement(command, True, True)

        elif command[1] > 1 and silent == False:
            movement(command, sprint = True)
            command[1] = command[1] - 1
            run_sprint(command)

        elif command[1] > 1 and silent == True:
            movement(command, sprint = True, silent= True)
            command[1] = command[1] - 1
            run_sprint(command, True)

def check_init(i, silent=False):
    if 'sprint' in i:
        i = i.split(' ')
        if silent == True:
            run_sprint(i, True)
        else:
            run_sprint(i)
    elif 'left' in i or 'right' in i:
        if silent == True:
            change_face(i, True)
        else:
            change_face(i) 
    elif 'forward' in i or 'back' in i:
        i = i.split(' ')
        if silent == True:
            movement(i, sprint=False, silent=True)
        else:
            movement(i)

def do_replay(command):
    for i in bot['history']:
        check_init(i)
            
    print(f" > {bot['name']} replayed {len(bot['history'])} commands.")
    print(f" > {bot['name']} now at position ({bot['pos_x']},{bot['pos_y']}).")

def do_replay_range(command):
    for count, i in enumerate(bot['history'][len(bot['history']) - int(command[1]):], 1):
        check_init(i)

    print(f" > {bot['name']} replayed {count} commands.")
    print(f" > {bot['name']} now at position ({bot['pos_x']},{bot['pos_y']}).")

def do_replay_range_silent(command):
    count = 0
    for i in bot['history'][len(bot['history']) - int(command[1]):]:
        check_init(i, silent=True)
        count += 1

    print(f" > {bot['name']} replayed {count} commands silently.")
    print(f" > {bot['name']} now at position ({bot['pos_x']},{bot['pos_y']}).")

def do_replay_range_reversed(command):
    count = 0
    for i in bot['history'][len(bot['history']) - int(command[1])::-1]:
        check_init(i)
        count += 1

    print(f" > {bot['name']} replayed {count} commands in reverse.")
    print(f" > {bot['name']} now at position ({bot['pos_x']},{bot['pos_y']}).")

def do_replay_range_dash(command):
    dash_split = command[1].split('-')
    count = 0
    for i in bot['history'][len(bot['history']) - int(dash_split[0]):len(bot['history']) - int(dash_split[1])]:
        check_init(i)
        count += 1

    print(f" > {bot['name']} replayed {count} commands.")
    print(f" > {bot['name']} now at position ({bot['pos_x']},{bot['pos_y']}).")

def do_replay_silent(command):
    for i in bot['history']:
        check_init(i, True)

    print(f" > {bot['name']} replayed {len(bot['history'])} commands silently.")
    print(f" > {bot['name']} now at position ({bot['pos_x']},{bot['pos_y']}).")

def do_replay_reversed(command):
    for i in reversed(bot['history']):
        check_init(i)

    print(f" > {bot['name']} replayed {len(bot['history'])} commands in reverse.")
    print(f" > {bot['name']} now at position ({bot['pos_x']},{bot['pos_y']}).")

def do_replay_reversed_silent(command):
    for i in reversed(bot['history']):
        check_init(i, True)
        
    print(f" > {bot['name']} replayed {len(bot['history'])} commands in reverse silently.")
    print(f" > {bot['name']} now at position ({bot['pos_x']},{bot['pos_y']}).")

def robot_start():

        global bot
        bot = {'name': '', 'pos_x': 0, 'pos_y': 0, 'face': 'n', 'history': []}

        get_bot_name()
        handle_command_input()

if __name__ == "__main__":
        robot_start()