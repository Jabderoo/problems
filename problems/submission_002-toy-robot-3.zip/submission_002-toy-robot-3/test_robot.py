import unittest
from io import StringIO
import sys
from test_base import run_unittests
from test_base import captured_io
import robot


class MyTestCase(unittest.TestCase):

    #Step 1 Name Robot
    def test_step1_then_off_Capitalize(self):
        with captured_io(StringIO('Jay\nOFF\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next? Jay: Shutting down..""", output)


    def test_step1_then_off_lower(self):
        with captured_io(StringIO('jay\nOff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? jay: Hello kiddo!
jay: What must I do next? jay: Shutting down..""", output)


    #Step 2 Sorry I dont Understand
    def test_step2_then_wrong_then_off(self):
    
        with captured_io(StringIO('Jay\nJump down\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next? Jay: Sorry, I did not understand 'Jump down'.
Jay: What must I do next? Jay: Shutting down..""", output)


    #Step 3 - 6 Forward and Back
    def test_back10_then_off(self):

        with captured_io(StringIO('Jay\nback 10\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved back by 10 steps.
 > Jay now at position (0,-10).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_back0_then_off(self):
        with captured_io(StringIO('Jay\nback 0\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved back by 0 steps.
 > Jay now at position (0,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_back10_fwk10_then_off(self):

        with captured_io(StringIO('Jay\nback 10\nforward 10\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved back by 10 steps.
 > Jay now at position (0,-10).
Jay: What must I do next?  > Jay moved forward by 10 steps.
 > Jay now at position (0,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    # Forward and Back with Sorry I dont understand (step 2)
    def test_forward_only_off(self):
    
        with captured_io(StringIO('Jay\nforward\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next? Jay: Sorry, I did not understand 'forward'.
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_back_only_off(self):
    
        with captured_io(StringIO('Jay\nback\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next? Jay: Sorry, I did not understand 'back'.
Jay: What must I do next? Jay: Shutting down..""", output)

    #Step 7 - 8
    def test_left_then_off(self):

        with captured_io(StringIO('Jay\nleft\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_step8_right_then_fwd10_then_off(self):

        with captured_io(StringIO('Jay\nright\nforward 10\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay moved forward by 10 steps.
 > Jay now at position (10,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_right_then_back10_then_off(self):

        with captured_io(StringIO('Jay\nright\nback 10\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay moved back by 10 steps.
 > Jay now at position (-10,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_step9_left_then_fwd10_then_off(self):

        with captured_io(StringIO('Jay\nleft\nforward 10\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay moved forward by 10 steps.
 > Jay now at position (-10,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_step9_left_then_back10_then_off(self):

        with captured_io(StringIO('Jay\nleft\nback 10\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay moved back by 10 steps.
 > Jay now at position (10,0).
Jay: What must I do next? Jay: Shutting down..""", output)
    
    # LEFT an RIGHT -/10 with Sorry I dont understand (step 2)
    def test_left_10_off(self):
    
        with captured_io(StringIO('Jay\nLEFT 10\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next? Jay: Sorry, I did not understand 'LEFT 10'.
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_RIGHT_n10_off(self):
        
        with captured_io(StringIO('Jay\nRIGHT -10\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next? Jay: Sorry, I did not understand 'RIGHT -10'.
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_whatsmyname_left_right_off(self):
    
        with captured_io(StringIO('Jay\nwhats my name\nleft\nright\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next? Jay: Sorry, I did not understand 'whats my name'.
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    #Step 10 Safe Zone
    def test_fwd200_onboarder_fwd1_then_off(self):

        with captured_io(StringIO('Jay\nforward 200\nforward 1\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved forward by 200 steps.
 > Jay now at position (0,200).
Jay: What must I do next? Jay: Sorry, I cannot go outside my safe zone.
 > Jay now at position (0,200).
Jay: What must I do next? Jay: Shutting down..""", output)

    
    def test_x2right_then_fwd201_then_off(self):

        with captured_io(StringIO('Jay\nright\nright\nforward 201\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,0).
Jay: What must I do next? Jay: Sorry, I cannot go outside my safe zone.
 > Jay now at position (0,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    
    #Step 11 Sprint 
    def test_sprint1_then_off(self):

        with captured_io(StringIO('Jay\nsprint 1\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved forward by 1 steps.
 > Jay now at position (0,1).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_sprint_sorry_then_off(self):
    
        with captured_io(StringIO('Jay\nsprint\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next? Jay: Sorry, I did not understand 'sprint'.
Jay: What must I do next? Jay: Shutting down..""", output)

    # Step 12 - 13 History and Replay
    def test_replay_left(self):
        
            with captured_io(StringIO('Jay\nleft\nleft\nforward 201\noff\n')) as (out, err):
                robot.robot_start()

            output = out.getvalue().strip()

            self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,0).
Jay: What must I do next? Jay: Sorry, I cannot go outside my safe zone.
 > Jay now at position (0,0).
Jay: What must I do next? Jay: Shutting down..""", output)
    
    def test_replay_right(self):
        
            with captured_io(StringIO('Jay\nright\nright\nforward 201\noff\n')) as (out, err):
                robot.robot_start()

            output = out.getvalue().strip()

            self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,0).
Jay: What must I do next? Jay: Sorry, I cannot go outside my safe zone.
 > Jay now at position (0,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_replay_sprint(self):
        
        with captured_io(StringIO('Jay\nsprint 4\nreplay\noff\n')) as (out, err):
            robot.robot_start()
        
        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved forward by 4 steps.
 > Jay moved forward by 3 steps.
 > Jay moved forward by 2 steps.
 > Jay moved forward by 1 steps.
 > Jay now at position (0,10).
Jay: What must I do next?  > Jay moved forward by 4 steps.
 > Jay moved forward by 3 steps.
 > Jay moved forward by 2 steps.
 > Jay moved forward by 1 steps.
 > Jay now at position (0,20).
 > Jay replayed 1 commands.
 > Jay now at position (0,20).
Jay: What must I do next? Jay: Shutting down..""", output)

# Step 14 Replay
    def test_replay_left(self):
        
            with captured_io(StringIO('Jay\nleft\nforward 10\nreplay\noff\n')) as (out, err):
                robot.robot_start()

            output = out.getvalue().strip()

            self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay moved forward by 10 steps.
 > Jay now at position (-10,0).
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (-10,0).
 > Jay moved forward by 10 steps.
 > Jay now at position (-10,-10).
 > Jay replayed 2 commands.
 > Jay now at position (-10,-10).
Jay: What must I do next? Jay: Shutting down..""", output)
    
    def test_replay_right(self):
            
            with captured_io(StringIO('Jay\nright\nforward 10\nreplay\noff\n')) as (out, err):
                robot.robot_start()

            output = out.getvalue().strip()

            self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay moved forward by 10 steps.
 > Jay now at position (10,0).
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (10,0).
 > Jay moved forward by 10 steps.
 > Jay now at position (10,-10).
 > Jay replayed 2 commands.
 > Jay now at position (10,-10).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_replay_sprint(self):
        
        with captured_io(StringIO('Jay\nsprint 4\nreplay\noff\n')) as (out, err):
            robot.robot_start()
        
        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved forward by 4 steps.
 > Jay moved forward by 3 steps.
 > Jay moved forward by 2 steps.
 > Jay moved forward by 1 steps.
 > Jay now at position (0,10).
Jay: What must I do next?  > Jay moved forward by 4 steps.
 > Jay moved forward by 3 steps.
 > Jay moved forward by 2 steps.
 > Jay moved forward by 1 steps.
 > Jay now at position (0,20).
 > Jay replayed 1 commands.
 > Jay now at position (0,20).
Jay: What must I do next? Jay: Shutting down..""", output)


    # Step 14 Replay Silent
    def test_replay_silent_left(self):
        
            with captured_io(StringIO('Jay\nleft\nforward 10\nreplay silent\noff\n')) as (out, err):
                robot.robot_start()

            output = out.getvalue().strip()

            self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay moved forward by 10 steps.
 > Jay now at position (-10,0).
Jay: What must I do next?  > Jay replayed 2 commands silently.
 > Jay now at position (-10,-10).
Jay: What must I do next? Jay: Shutting down..""", output)
    
    def test_replay_silent_left(self):
            
            with captured_io(StringIO('Jay\nright\nforward 10\nreplay silent\noff\n')) as (out, err):
                robot.robot_start()

            output = out.getvalue().strip()

            self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay moved forward by 10 steps.
 > Jay now at position (10,0).
Jay: What must I do next?  > Jay replayed 2 commands silently.
 > Jay now at position (10,-10).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_replay_sprint_silent(self):
        
        with captured_io(StringIO('Jay\nsprint 4\nreplay silent\noff\n')) as (out, err):
            robot.robot_start()
        
        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved forward by 4 steps.
 > Jay moved forward by 3 steps.
 > Jay moved forward by 2 steps.
 > Jay moved forward by 1 steps.
 > Jay now at position (0,10).
Jay: What must I do next?  > Jay replayed 1 commands silently.
 > Jay now at position (0,20).
Jay: What must I do next? Jay: Shutting down..""", output)


    def test_replay_range_left_right(self):

        with captured_io(StringIO('Jay\nleft\nright\nforward 3\nreplay 2\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,0).
Jay: What must I do next?  > Jay moved forward by 3 steps.
 > Jay now at position (0,3).
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,3).
 > Jay moved forward by 3 steps.
 > Jay now at position (3,3).
 > Jay replayed 2 commands.
 > Jay now at position (3,3).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_replay_range_silent(self):

        with captured_io(StringIO('Jay\nforward 3\nright\nforward 3\nreplay 2 silent\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved forward by 3 steps.
 > Jay now at position (0,3).
Jay: What must I do next?  > Jay turned right.
 > Jay now at position (0,3).
Jay: What must I do next?  > Jay moved forward by 3 steps.
 > Jay now at position (3,3).
Jay: What must I do next?  > Jay replayed 2 commands silently.
 > Jay now at position (3,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_replay_reversed(self):

        with captured_io(StringIO('Jay\nforward 3\nleft\nforward 2\nreplay reversed\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved forward by 3 steps.
 > Jay now at position (0,3).
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,3).
Jay: What must I do next?  > Jay moved forward by 2 steps.
 > Jay now at position (-2,3).
Jay: What must I do next?  > Jay moved forward by 2 steps.
 > Jay now at position (-4,3).
 > Jay turned left.
 > Jay now at position (-4,3).
 > Jay moved forward by 3 steps.
 > Jay now at position (-4,0).
 > Jay replayed 3 commands in reverse.
 > Jay now at position (-4,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_replay_reversed_silent(self):

        with captured_io(StringIO('Jay\nforward 3\nleft\nforward 2\nreplay reversed silent\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved forward by 3 steps.
 > Jay now at position (0,3).
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,3).
Jay: What must I do next?  > Jay moved forward by 2 steps.
 > Jay now at position (-2,3).
Jay: What must I do next?  > Jay replayed 3 commands in reverse silently.
 > Jay now at position (-4,0).
Jay: What must I do next? Jay: Shutting down..""", output)

    def test_replay_range_reversed(self):
         
        with captured_io(StringIO('Jay\nforward 2\nforward 3\nleft\nforward 3\nreplay 2 reversed\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved forward by 2 steps.
 > Jay now at position (0,2).
Jay: What must I do next?  > Jay moved forward by 3 steps.
 > Jay now at position (0,5).
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,5).
Jay: What must I do next?  > Jay moved forward by 3 steps.
 > Jay now at position (-3,5).
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (-3,5).
 > Jay moved forward by 3 steps.
 > Jay now at position (-3,2).
 > Jay moved forward by 2 steps.
 > Jay now at position (-3,0).
 > Jay replayed 3 commands in reverse.
 > Jay now at position (-3,0).
Jay: What must I do next? Jay: Shutting down..""", output)


    def test_replay_range_dash(self):

        with captured_io(StringIO('Jay\nforward 3\nleft\nforward 4\nforward 2\nreplay 2-1\noff\n')) as (out, err):
            robot.robot_start()

        output = out.getvalue().strip()

        self.assertEqual("""What do you want to name your robot? Jay: Hello kiddo!
Jay: What must I do next?  > Jay moved forward by 3 steps.
 > Jay now at position (0,3).
Jay: What must I do next?  > Jay turned left.
 > Jay now at position (0,3).
Jay: What must I do next?  > Jay moved forward by 4 steps.
 > Jay now at position (-4,3).
Jay: What must I do next?  > Jay moved forward by 2 steps.
 > Jay now at position (-6,3).
Jay: What must I do next?  > Jay moved forward by 4 steps.
 > Jay now at position (-10,3).
 > Jay replayed 1 commands.
 > Jay now at position (-10,3).
Jay: What must I do next? Jay: Shutting down..""", output)
if __name__ == '__main__':
    unittest.main()